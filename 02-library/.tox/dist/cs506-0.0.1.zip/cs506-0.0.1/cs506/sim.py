import math

def euclidean_dist(x, y):
    return abs((x[0]-y[0]) + (x[1]-y[1]))

def manhattan_dist(x, y):
    value = 0
    for axis in range(len(x)):
        value += abs(x[axis]-y[axis])
    return value

def jaccard_dist(x, y):
    intersect = set()
    union = set()
    for axis in x:
        union.add(axis)
        if axis in y:
            intersect.add(axis)
    for axis in y:
        union.add(axis)
    index = len(intersect)/len(union)
    return 1 - index

def cosine_sim(x, y):
    numerator = 0
    denom_x = 0
    denom_y = 0
    for axis in range(len(x)):
        numerator += x[axis]*y[axis]
        denom_x += x[axis]**2
        denom_y += y[axis]**2
    denom_x = math.sqrt(denom_x)
    denom_y = math.sqrt(denom_y)
    index = numerator/(denom_x*denom_y)
    return index

# Feel free to add more
